// @ts-nocheck
// Pure stateless translation between ModCDP and raw CDP messages.
// No I/O, no maps, no classes. Trivial to port to any language.
// Used on both the Node side (proxy + client) and the extension service worker
// side, so the binding payload format only has one definition.
export const UPSTREAM_EVENT_BINDING_NAME = "__ModCDP_event_from_upstream__";
export const CUSTOM_EVENT_BINDING_NAME = "__ModCDP_custom_event__";
export const DEFAULT_CLIENT_ROUTES = {
    "Mod.*": "service_worker",
    "Custom.*": "service_worker",
    "*.*": "service_worker",
};
function normalizeModCDPName(value) {
    if (typeof value === "string")
        return value;
    const meta = typeof value?.meta === "function" ? value.meta() : undefined;
    const name = value?.cdp_command_name ??
        value?.cdp_event_name ??
        (typeof meta?.cdp_command_name === "string" ? meta.cdp_command_name : undefined) ??
        (typeof meta?.cdp_event_name === "string" ? meta.cdp_event_name : undefined) ??
        value?.id ??
        (typeof meta?.id === "string" ? meta.id : undefined) ??
        (typeof meta?.name === "string" ? meta.name : undefined) ??
        value?.name;
    if (typeof name !== "string" || !name)
        throw new Error("Expected a CDP name string or a named CDP schema/alias.");
    return name;
}
export function routeFor(method, routes = {}) {
    if (Object.prototype.hasOwnProperty.call(routes, method))
        return routes[method];
    let bestPrefixLen = -1;
    let bestRoute = null;
    for (const [pattern, route] of Object.entries(routes)) {
        if (pattern === "*.*" || !pattern.endsWith(".*"))
            continue;
        const prefix = pattern.slice(0, -1);
        if (method.startsWith(prefix) && prefix.length > bestPrefixLen) {
            bestPrefixLen = prefix.length;
            bestRoute = route;
        }
    }
    if (bestRoute !== null)
        return bestRoute;
    if (Object.prototype.hasOwnProperty.call(routes, "*.*"))
        return routes["*.*"];
    return "direct_cdp";
}
// --- outbound: ModCDP method -> Runtime.* params on the extension session --
export function wrapModCDPEvaluate({ expression, params = {}, cdpSessionId = null, }) {
    return {
        functionDeclaration: `
      async function() {
        const params = ${JSON.stringify(params)};
        const cdp = globalThis.ModCDP.attachToSession(${JSON.stringify(cdpSessionId)});
        const ModCDP = globalThis.ModCDP;
        const chrome = globalThis.chrome;
        const value = (${expression});
        return typeof value === "function" ? await value(params) : value;
      }
    `,
        awaitPromise: true,
        returnByValue: true,
    };
}
export function wrapModCDPAddCustomCommand({ name, expression, }) {
    const commandName = normalizeModCDPName(name);
    return {
        functionDeclaration: `
      function() {
        return globalThis.ModCDP.addCustomCommand({
          name: ${JSON.stringify(commandName)},
          params_schema: null,
          result_schema: null,
          expression: ${JSON.stringify(expression)},
          handler: async (params, cdpSessionId, method) => {
            const cdp = globalThis.ModCDP.attachToSession(cdpSessionId);
            const ModCDP = globalThis.ModCDP;
            const chrome = globalThis.chrome;
            const handler = (${expression});
            return await handler(params || {}, method);
          },
        });
      }
    `,
        awaitPromise: true,
        returnByValue: true,
    };
}
export function wrapModCDPAddCustomEvent({ name }) {
    const eventName = normalizeModCDPName(name);
    return {
        functionDeclaration: `
      function() {
        return globalThis.ModCDP.addCustomEvent({
        name: ${JSON.stringify(eventName)},
        event_schema: null,
        });
      }
    `,
        awaitPromise: true,
        returnByValue: true,
    };
}
export function wrapModCDPAddMiddleware({ name = "*", phase, expression, }) {
    const middlewareName = normalizeModCDPName(name);
    return {
        functionDeclaration: `
      function() {
        return globalThis.ModCDP.addMiddleware({
          name: ${JSON.stringify(middlewareName)},
          phase: ${JSON.stringify(phase)},
          expression: ${JSON.stringify(expression)},
          handler: async (payload, next, context = {}) => {
            const cdp = globalThis.ModCDP.attachToSession(context.cdpSessionId ?? null);
            const ModCDP = globalThis.ModCDP;
            const chrome = globalThis.chrome;
            const middleware = (${expression});
            return await middleware(payload, next, context);
          },
        });
      }
    `,
        awaitPromise: true,
        returnByValue: true,
    };
}
export function wrapCustomCommand(method, params = {}, cdpSessionId = null) {
    return {
        functionDeclaration: `async function() { return await globalThis.ModCDP.handleCommand(${JSON.stringify(method)}, ${JSON.stringify(params)}, ${JSON.stringify(cdpSessionId)}); }`,
        awaitPromise: true,
        returnByValue: true,
    };
}
function wrapServiceWorkerCommand(method, params = {}, cdpSessionId = null) {
    if (method === "Mod.ping" && !Object.prototype.hasOwnProperty.call(params, "sent_at")) {
        params = { ...params, sent_at: Date.now() };
    }
    if (method === "Mod.addCustomEvent") {
        const eventParams = params;
        const eventName = normalizeModCDPName(eventParams.name);
        return [
            {
                method: "Runtime.callFunctionOn",
                params: wrapModCDPAddCustomEvent({ name: eventName }),
                unwrap: "runtime",
            },
        ];
    }
    let runtimeParams;
    if (method === "Mod.evaluate") {
        const evaluateParams = params;
        runtimeParams = wrapModCDPEvaluate({
            ...evaluateParams,
            cdpSessionId: evaluateParams.cdpSessionId ?? cdpSessionId,
        });
    }
    else if (method === "Mod.addCustomCommand") {
        runtimeParams = wrapModCDPAddCustomCommand(params);
    }
    else if (method === "Mod.addMiddleware") {
        runtimeParams = wrapModCDPAddMiddleware(params);
    }
    else {
        runtimeParams = wrapCustomCommand(method, params, params.cdpSessionId ?? cdpSessionId);
    }
    return [
        {
            method: "Runtime.callFunctionOn",
            params: runtimeParams,
            unwrap: "runtime",
        },
    ];
}
export function wrapCommandIfNeeded(method, params = {}, { routes = DEFAULT_CLIENT_ROUTES, cdpSessionId = null } = {}) {
    params = params ?? {};
    const route = routeFor(method, routes);
    if (route === "direct_cdp") {
        return {
            route,
            target: "direct_cdp",
            steps: [{ method, params }],
        };
    }
    if (route === "service_worker") {
        return {
            route,
            target: "service_worker",
            steps: wrapServiceWorkerCommand(method, params, cdpSessionId),
        };
    }
    throw new Error(`Unsupported client route "${route}" for ${method}`);
}
// --- inbound: Runtime.* result/event -> ModCDP value/event ----------------
function unwrapRuntimeResponse(result) {
    if (result?.exceptionDetails) {
        const ex = result.exceptionDetails;
        throw new Error(ex.exception?.description || ex.text || "Runtime call failed");
    }
    return result?.result?.value;
}
export function unwrapResponseIfNeeded(result, unwrap = null) {
    return unwrap === "runtime" ? unwrapRuntimeResponse(result) : (result ?? {});
}
// Returns { event, data } or null when the binding is not a ModCDP event,
// when a custom binding payload is scoped to a different cdpSessionId than
// ourSessionId, or when the payload string is not valid JSON.
export function unwrapEventIfNeeded(method, params, sessionId = null, ourSessionId = null) {
    if (method !== "Runtime.bindingCalled")
        return null;
    let payload;
    try {
        payload = JSON.parse(params.payload || "{}");
    }
    catch {
        return null;
    }
    if (payload == null || typeof payload !== "object")
        return null;
    const bindingName = params?.name || "";
    const isUpstreamEventBinding = bindingName === UPSTREAM_EVENT_BINDING_NAME;
    const isCustomEventBinding = bindingName === CUSTOM_EVENT_BINDING_NAME;
    if (!isUpstreamEventBinding && !isCustomEventBinding)
        return null;
    const payloadEvent = typeof payload.event === "string" && payload.event.length > 0 ? payload.event : null;
    if (payloadEvent == null)
        return null;
    if (payloadEvent === UPSTREAM_EVENT_BINDING_NAME || payloadEvent === CUSTOM_EVENT_BINDING_NAME)
        return null;
    const data = Object.prototype.hasOwnProperty.call(payload, "data") ? payload.data : payload;
    const sourceSessionId = typeof payload.cdpSessionId === "string" ? payload.cdpSessionId : sessionId;
    return { event: payloadEvent, data, sessionId: sourceSessionId };
}
// --- shared encoder used by the extension service worker --------------------
export function encodeBindingPayload({ event, data, cdpSessionId = null }) {
    return JSON.stringify({ event, data, cdpSessionId });
}
//# sourceMappingURL=translate.js.map