globalThis.__MODCDP_RUNTIME_CONFIG__ ??= {};
export {};
//# sourceMappingURL=config.js.map